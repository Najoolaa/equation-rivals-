const test = require('node:test');
const assert = require('node:assert/strict');
const { TARGETS, formula, makeRoom, joinRoom, getRole, submitMove, rematch, snapshot } = require('../engine');
function newGame() {
  const r = makeRoom('AAAAAA', 'A', 'secretA');
  joinRoom(r, 'B', 'secretB');
  return r;
}
const solve = (target) => Array.from({ length: 7 }, (_, x) => x).find(x => formula(x) === target);

test('formula uses every number from zero to six exactly once', () => {
  assert.deepEqual([...new Set(Array.from({length:7}, (_,i) => formula(i)))].sort(), [0,1,2,3,4,5,6]);
});
test('player joins room and sees no rival session key', () => {
  const r = newGame();
  assert.equal(getRole(r, 'secretB'), 'architect');
  const s = snapshot(r, 'artist');
  assert.equal(s.status, 'playing');
  assert.equal(JSON.stringify(s).includes('secret'), false);
});
test('simultaneous moves resolve only after both submit', () => {
  const r = newGame();
  submitMove(r, 'artist', {tile:0,x:solve(TARGETS.artist[0]),prediction:null});
  assert.equal(r.round, 1);
  assert.deepEqual(r.players.artist.filled, []);
  submitMove(r, 'architect', {tile:0,x:solve(TARGETS.architect[0]),prediction:null});
  assert.equal(r.round, 2);
  assert.deepEqual(r.players.artist.filled, [0]);
  assert.deepEqual(r.players.architect.filled, [0]);
});
test('prediction blocks one correct move then the tile becomes guarded', () => {
  const r = newGame();
  submitMove(r,'artist',{tile:0,x:solve(TARGETS.artist[0]),prediction:null});
  submitMove(r,'architect',{tile:0,x:solve(TARGETS.architect[0]),prediction:0});
  assert.deepEqual(r.players.artist.filled, []);
  assert.deepEqual(r.players.artist.guarded,[0]);
  assert.equal(r.lastRound.results.artist.outcome,'blocked');
  submitMove(r,'artist',{tile:0,x:solve(TARGETS.artist[0]),prediction:null});
  submitMove(r,'architect',{tile:1,x:solve(TARGETS.architect[1]),prediction:0});
  assert.deepEqual(r.players.artist.filled,[0]);
});
test('wrong math does not place tile; bad inputs rejected', () => {
  const r = newGame();
  assert.throws(() => submitMove(r,'artist',{tile:20,x:2,prediction:null}), /unfinished/);
  assert.throws(() => submitMove(r,'artist',{tile:0,x:7,prediction:null}), /between/);
  const wrong = (solve(TARGETS.artist[0]) + 1) % 7;
  submitMove(r,'artist',{tile:0,x:wrong,prediction:null});
  assert.throws(() => submitMove(r,'artist',{tile:1,x:0,prediction:null}),/locked/);
  submitMove(r,'architect',{tile:0,x:solve(TARGETS.architect[0]),prediction:null});
  assert.equal(r.lastRound.results.artist.outcome,'wrong');
  assert.equal(r.players.artist.filled.length,0);
});
test('finish correctly, require both for rematch', () => {
  const r = newGame();
  for (let i=0; i<9; i++) {
    submitMove(r,'artist',{tile:i,x:solve(TARGETS.artist[i]),prediction:null});
    submitMove(r,'architect',{tile:i,x:solve(TARGETS.architect[i]),prediction:null});
  }
  assert.equal(r.status,'finished');
  assert.equal(r.winner,'draw');
  rematch(r,'artist');
  assert.equal(r.status,'finished');
  rematch(r,'architect');
  assert.equal(r.status,'playing');
  assert.equal(r.round,1);
  assert.deepEqual(r.players.artist.filled,[]);
});
