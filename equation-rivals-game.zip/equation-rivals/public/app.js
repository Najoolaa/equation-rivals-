(() => {
  'use strict';

  const $ = selector => document.querySelector(selector);
  const app = {
    session: null, state: null, events: null,
    tile: null, x: null, prediction: null,
    activeRound: null, busy: false,
  };
  const roleName = { artist: 'The Artist', architect: 'The Architect' };
  const roleMission = { artist: 'THE MOSAIC', architect: 'THE CITY' };
  const escapeHtml = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  function notice(message) {
    const box = $('#notice');
    box.textContent = message;
    box.classList.toggle('hidden', !message);
    if (message) box.scrollIntoView({behavior:'smooth', block:'nearest'});
  }
  function show(which, on) { $(which).classList.toggle('hidden', !on); }
  function updateConnection(text, good = true) {
    $('#connection').textContent = `${good ? '●' : '○'} ${text}`;
    $('#connection').style.color = good ? '#8bd7ce' : '#f4c17c';
  }
  function setSession(data) {
    app.session = { code:data.code, token:data.token, role:data.role };
    localStorage.setItem(`equation-rivals-${data.code}`, JSON.stringify(app.session));
    localStorage.setItem('equation-rivals-name', $('#nickname').value.trim());
    const url = new URL(window.location.href);
    url.searchParams.set('room', data.code);
    window.history.replaceState({}, '', url);
    applyState(data.state);
    connect();
    notice('');
  }
  async function api(url, body, method = 'POST') {
    const response = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    let data;
    try { data = await response.json(); } catch { throw new Error('Could not reach the game server.'); }
    if (!response.ok) throw new Error(data.error || 'Something went wrong.');
    return data;
  }
  function name() {
    const text = $('#nickname').value.trim();
    if (!text) throw new Error('Please enter your name first.');
    return text;
  }
  async function createRoom() {
    if (app.busy) return;
    try {
      app.busy = true;
      const data = await api('/api/rooms', {name:name()});
      setSession(data);
    } catch(e) { notice(e.message); }
    finally { app.busy = false; }
  }
  async function joinRoom() {
    if (app.busy) return;
    try {
      const code = $('#room-code').value.trim().toUpperCase();
      if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code)) throw new Error('Enter the six-character room code.');
      const nick = name();
      app.busy = true;
      const saved = localStorage.getItem(`equation-rivals-${code}`);
      if (saved) {
        const session = JSON.parse(saved);
        const response = await fetch(`/api/rooms/${code}?token=${encodeURIComponent(session.token)}`);
        if (response.ok) {
          const state = await response.json();
          setSession({...session, state});
          return;
        }
      }
      const data = await api(`/api/rooms/${code}/join`, {name:nick});
      setSession(data);
    } catch(e) { notice(e.message); }
    finally { app.busy = false; }
  }
  function connect() {
    app.events?.close();
    if (!app.session) return;
    updateConnection('Connecting…', false);
    app.events = new EventSource(`/api/rooms/${app.session.code}/events?token=${encodeURIComponent(app.session.token)}`);
    app.events.addEventListener('state', event => {
      try { applyState(JSON.parse(event.data)); updateConnection('Live and connected'); }
      catch(e) { notice('Could not read game updates.'); }
    });
    app.events.onerror = () => updateConnection('Reconnecting…', false);
  }
  function applyState(state) {
    if (app.activeRound !== state.round || (app.state?.status === 'finished' && state.status === 'playing')) {
      app.tile = null;
      app.x = null;
      app.prediction = null;
      app.activeRound = state.round;
    }
    app.state = state;
    render();
  }
  function render() {
    const s = app.state;
    show('#lobby', !s);
    show('#arena', !!s);
    if (!s) return;
    $('#room-display').textContent = s.code;
    show('#waiting', s.status === 'waiting');
    show('#playing', s.status !== 'waiting');
    if (s.status === 'waiting') return;
    const myRole = s.you;
    const otherRole = myRole === 'artist' ? 'architect' : 'artist';
    const me = s.players[myRole];
    const them = s.players[otherRole];
    if (!me || !them) return;
    $('#status-main').textContent = s.status === 'finished'
      ? '🏁 Game over!'
      : me.locked ? '🔒 Move locked — waiting for your rival' : `Round ${s.round} — make your move`;
    $('#status-sub').textContent = `${me.name} (${roleName[myRole]}) vs ${them.name} (${roleName[otherRole]})`;
    $('#boards').innerHTML = board(myRole, true) + board(otherRole, false);
    document.querySelectorAll('.tile.actionable').forEach(button => button.addEventListener('click', () => {
      if (app.state.status !== 'playing' || me.locked) return;
      app.tile = Number(button.dataset.tile);
      render();
    }));
    document.querySelectorAll('.tile.guessing').forEach(button => button.addEventListener('click', () => {
      if (app.state.status !== 'playing' || me.locked) return;
      const value = Number(button.dataset.tile);
      app.prediction = app.prediction === value ? null : value;
      render();
    }));
    const playable = s.status === 'playing';
    show('#play-panel', playable);
    if (playable) {
      $('#play-panel').classList.toggle('is-locked', me.locked);
      $('#round-indicator').textContent = `ROUND ${s.round}`;
      $('#tile-selected').textContent = app.tile === null ? 'No square selected' : `Square ${app.tile + 1} — target y = ${s.targets[myRole][app.tile]}`;
      $('#prediction-selected').textContent = app.prediction === null ? 'Passing — no prediction' : `Predict square ${app.prediction + 1}`;
      $('#number-picks').innerHTML = Array.from({length:7},(_,x) => `<button type="button" class="x-pick ${app.x === x ? 'active' : ''}" data-x="${x}" aria-pressed="${app.x === x}">${x}</button>`).join('');
      document.querySelectorAll('.x-pick').forEach(button => button.addEventListener('click', () => {
        if (me.locked) return;
        app.x = Number(button.dataset.x);
        render();
      }));
      $('#lock-move').disabled = me.locked || app.busy || app.tile === null || app.x === null;
      $('#lock-move').innerHTML = me.locked ? 'Waiting for rival…' : 'Lock in move <span>→</span>';
      $('#pass-prediction').disabled = me.locked;
    }
    renderLastRound();
    renderFinish();
  }

  function board(role, isMe) {
    const s = app.state;
    const player = s.players[role];
    const count = player.filled.length;
    const current = isMe ? app.tile : app.prediction;
    const canInteract = s.status === 'playing' && !s.players[s.you].locked;
    const tiles = s.targets[role].map((target, i) => {
      const built = player.filled.includes(i);
      const guarded = player.guarded.includes(i);
      const canSelect = canInteract && !built && (isMe || !guarded);
      const selected = current === i && !built;
      const tileClass = [
        'tile', role, built ? 'completed' : '',
        canSelect ? (isMe ? 'actionable' : 'guessing') : '',
        selected ? (isMe ? 'selected' : 'predicted') : ''
      ].filter(Boolean).join(' ');
      let content = `<span class="tile-number">${String(i+1).padStart(2, '0')}</span>`;
      if (built) content += role === 'artist' ? '<span class="piece"><span class="art-shape"></span></span>' : '<span class="piece"><i></i><i></i><i></i><i></i></span>';
      else content += `<span class="tile-target">${target}</span><span class="tile-hint">TARGET y</span>`;
      if (guarded && !built) content += `<span class="tile-protected" title="Shield: this square cannot be blocked again">🛡</span>`;
      const label = built ? 'completed' : `target y equals ${target}${guarded ? ', protected from blocks' : ''}`;
      return `<button type="button" class="${tileClass}" data-value="${target}" data-tile="${i}" ${canSelect ? '' : 'disabled'} aria-pressed="${selected}" aria-label="${roleName[role]} square ${i + 1}, ${label}">${content}</button>`;
    }).join('');
    return `<section class="board-panel ${isMe ? 'mine' : 'opponent'}" aria-label="${isMe ? 'Your' : 'Opponent'} mission">
      <div class="board-heading"><div><span class="side-tag ${isMe ? 'mine' : 'rival'}">${isMe ? '✦ YOUR MISSION' : '↗ RIVAL MISSION'}</span><h3>${roleName[role]} <small style="font-size:11px;font-weight:500;color:#93a1c0">${escapeHtml(player.name)}</small></h3><p>${roleMission[role]} · ${role === 'artist' ? 'A living artwork' : 'A mathematical city'}</p></div><div class="progress-total">${count}<span> / 9</span></div></div>
      <div class="progress-bar"><div style="width:${Math.round(count / 9 * 100)}%"></div></div>
      <div class="tiles">${tiles}</div>
      <p class="board-tip">${isMe ? '↑ Tap any unfinished tile, then find x to match its target y.' : '↑ Tap an unprotected unfinished tile to guess their next move.'}</p>
    </section>`;
  }
  function renderLastRound() {
    const last = app.state.lastRound;
    show('#last-result', !!last);
    if (!last) return;
    const messages = {
      built: ['✓ Piece placed!', 'result-badge'],
      blocked: ['⛔ Move predicted and blocked. This square now has a shield.', 'result-badge bad'],
      wrong: ['✕ Incorrect equation result — no piece placed.', 'result-badge bad'],
    };
    const entries = ['artist', 'architect'].map(role => {
      const item = last.results[role];
      const [message, kind] = messages[item.outcome];
      const name = escapeHtml(app.state.players[role].name);
      return `<div class="result-item"><strong>${roleName[role]} · ${name}</strong>Chose square ${item.tile + 1} (target y = ${item.target}) with x = ${item.x}, calculated y = ${item.output}.<br/><span class="${kind}">${message}</span>${item.prediction === null ? '<br/>Prediction: passed.' : `<br/>Prediction: rival square ${item.prediction + 1}.`}</div>`;
    });
    $('#last-result').innerHTML = `<h3>↳ Round ${last.number} reveal</h3><div class="results">${entries.join('')}</div>`;
  }
  function renderFinish() {
    const s = app.state;
    show('#game-end', s.status === 'finished');
    if (s.status !== 'finished') return;
    const message = s.winner === 'draw' ? 'It’s a draw!' : s.winner === s.you ? 'You won! ✨' : 'Your rival won!';
    const detail = s.winner === 'draw' ? 'Both designs were completed in the same round.' : `${roleName[s.winner]} completed all nine pieces first.`;
    const ready = s.players[s.you].ready;
    $('#game-end').innerHTML = `<h2>${message}</h2><p>${detail} Want another round?</p><button class="primary-button" id="rematch" ${ready ? 'disabled' : ''}>${ready ? 'Waiting for rival to rematch…' : 'Play again →'}</button>`;
    $('#rematch')?.addEventListener('click', rematch);
  }
  async function submit() {
    const s = app.state;
    if (app.busy || !s || s.status !== 'playing' || app.tile === null || app.x === null) return;
    app.busy = true;
    try {
      const next = await api(`/api/rooms/${s.code}/submit`, {
        token:app.session.token, tile:app.tile, x:app.x, prediction:app.prediction,
      });
      applyState(next);
      notice('');
    } catch(e) { notice(e.message); }
    finally { app.busy = false; render(); }
  }
  async function rematch() {
    if (!app.session) return;
    try {
      app.busy = true;
      const next = await api(`/api/rooms/${app.session.code}/rematch`, {token:app.session.token});
      applyState(next);
    } catch(e) { notice(e.message); }
    finally { app.busy = false; }
  }
  function rules(showIt) {
    show('#rules-modal', showIt);
    if (showIt) $('#rules-close').focus();
  }
  async function copyInvite() {
    const url = new URL(window.location.href);
    url.searchParams.set('room', app.state.code);
    const share = url.toString();
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(share);
      else throw new Error('clipboard unsupported');
      $('#invite').textContent = 'Copied! ✓';
      setTimeout(() => $('#invite').textContent = 'Copy invite link ↗', 1800);
    } catch {
      window.prompt('Copy this invite link and send it to a friend:', share);
    }
  }
  function init() {
    $('#nickname').value = localStorage.getItem('equation-rivals-name') || '';
    const room = new URL(window.location.href).searchParams.get('room')?.toUpperCase();
    if (room) $('#room-code').value = room;
    $('#create').addEventListener('click', createRoom);
    $('#join').addEventListener('click', joinRoom);
    $('#room-code').addEventListener('keydown', e => { if(e.key === 'Enter') joinRoom(); });
    $('#nickname').addEventListener('keydown', e => { if(e.key === 'Enter') room ? joinRoom() : createRoom(); });
    $('#invite').addEventListener('click', copyInvite);
    $('#lock-move').addEventListener('click', submit);
    $('#pass-prediction').addEventListener('click', () => { app.prediction = null; render(); });
    $('#rules-open').addEventListener('click', () => rules(true));
    $('#rules-close').addEventListener('click', () => rules(false));
    $('#rules-got-it').addEventListener('click', () => rules(false));
    $('#rules-modal').addEventListener('click', e => { if (e.target.id === 'rules-modal') rules(false); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape') rules(false); });
    if (room) {
      const saved = localStorage.getItem(`equation-rivals-${room}`);
      if (saved) {
        try {
          const session = JSON.parse(saved);
          fetch(`/api/rooms/${room}?token=${encodeURIComponent(session.token)}`)
            .then(async response => {
              if (!response.ok) throw new Error('Old room expired. Create or join a new game.');
              setSession({...session,state:await response.json()});
            }).catch(e => {localStorage.removeItem(`equation-rivals-${room}`);notice(e.message);});
        } catch { localStorage.removeItem(`equation-rivals-${room}`); }
      }
    }
  }
  init();
})();
